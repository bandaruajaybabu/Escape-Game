# Detective-Game
Private Detective is a game where users can use their analytical skills to find the culprit.

1. Users must read the clue cards to eliminate the suspects
2. User can click on the cards to eliminate the suspects.
3. Upon the final card, they will receive a prompt, they finally arrest their suspect and see if they have selected the correct culprit
